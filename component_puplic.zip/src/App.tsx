import "./App.css";
import Drag3Dmodel from "./components/3DModelDrag";
import Main from "./components/prevnext/main";
import Seance from "./components/sence";
import StreamComponent from "./components/StreamComponent";
import { WrapperDnd } from "./DndWrapper";

function App() {
  return (
    <div className="App">
      {/* <Main /> */}
      <WrapperDnd />
    </div>
  );
}

export default App;

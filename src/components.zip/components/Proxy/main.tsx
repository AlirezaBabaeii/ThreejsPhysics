import A from "./A";
import B from "./B";
export default function Main() {
  return (
    <div>
      <label>A</label>
      <A />
      <label>B</label>
      <B />
    </div>
  );
}

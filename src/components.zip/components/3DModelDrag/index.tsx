// // import { useDrag } from "react-dnd";
// import { OrbitControls } from "@react-three/drei";
// import { Canvas } from "@react-three/fiber";
// import Draggable from "react-draggable";
// export default function Drag3Dmodel() {
//   return (
//     <Canvas>
//       {/* <Draggable> */}
//       <mesh castShadow scale={[0.4, 0.4, 1]}>
//         <boxGeometry />
//         <meshStandardMaterial color={"#e056fd"} />
//       </mesh>{" "}
//       {/* </Draggable> */}
//       <OrbitControls />
//     </Canvas>
//   );
// }

import React, { useState, useRef } from "react";

import { useDrag } from "@use-gesture/react";
import { OrbitControls, useHelper, PerspectiveCamera } from "@react-three/drei";
import { Canvas, useThree } from "@react-three/fiber";
import * as THREE from "three";

function Obj({ scale = 1, z = 0, opacity = 1 }) {
  const { viewport } = useThree();
  const [hovered, hover] = useState(false);
  const [position, set] = useState<[number, number, number]>([0, 0, 0]);

  const bind = useDrag(({ event, offset: [x, y] }) => {
    event.stopPropagation();

    const aspect = viewport.getCurrentViewport().factor;

    set([x / aspect, -y / aspect, 0]);
  });

  const mesh = useRef<THREE.Mesh>();

  // useFrame(() => {
  //   mesh.current!.rotation.x = mesh.current!.rotation.y += 0.01;
  // });

  return (
    <mesh
      // bind drag property

      {...(bind() as any)}
      // use drag property

      onPointerOver={(e) => {
        e.stopPropagation();
        hover(true);
      }}
      onPointerOut={(e) => {
        e.stopPropagation();
        hover(false);
      }}
      /// mesh property

      ref={mesh}
      position={position}
      onClick={(e) => {
        e.stopPropagation();
        console.log("clicked", { z });
      }}
      castShadow
      scale={[1, 1, 1]}
    >
      <boxGeometry />
      <meshStandardMaterial color={"#e056fd"} />
    </mesh>
  );
}

// function Camera() {
//   const ref = useRef();
//   const camera = useCamera(ref);
//   useHelper(camera, PerspectiveCameraHelper);

//   return (
//     <perspectiveCamera
//       ref={ref}
//       position={[0, 0, 5]}
//       fov={75}
//       aspect={window.innerWidth / window.innerHeight}
//       near={0.1}
//       far={1000}
//     />
//   );
// }

export default function App() {
  return (
    <Canvas
      camera={{ fov: 30, near: 6, far: 2000, position: [0.5, 1, 10] }}
      style={{ background: "black", height: "100vh", width: "100%" }}
    >
      <CameraHelper />
      <ambientLight intensity={0.5} />

      <spotLight position={[10, 10, 10]} angle={0.15} penumbra={1} />
      <pointLight position={[-10, -10, -10]} />
      <Obj />
      {/* <Obj  /> */}
      {/* <OrbitControls /> */}
    </Canvas>
  );
}

const CameraHelper = () => {
  const camera = useRef();
  useHelper(camera, THREE.CameraHelper);
  return (
    <>
      <ambientLight intensity={1} />
      <PerspectiveCamera
        ref={camera}
        near={1}
        far={4}
        position={[0, 0, 0]}
      ></PerspectiveCamera>
      <mesh>
        <boxGeometry />
        <meshBasicMaterial color="red" />
      </mesh>
    </>
  );
};
